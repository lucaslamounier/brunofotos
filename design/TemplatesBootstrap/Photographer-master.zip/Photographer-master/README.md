#Photographer

An awesome free one page HTML template for your startup business or personal website.

#Features

- A very Unique, Mordern and beautiful Design.
- Background Slider
- Optimized Code & Content
- HiDPI / Retina Ready
- Clean Code
- Cross-browser Compatibility
- CSS3 Animations
- SEO Optimized
- 100% Fully Customizable
- Sticky Header 
- Google Fonts
- Built with HTML5 & CSS3
- Strong focus on Usability and UX
- Responsive layout
- CSS Framework - Bootstrap 3
- FontAwesome Icon Integrated
- Clean and stylish UI
- Smooth CSS3 animation
- Well commented coding
- Easy to use
- It's Free!


#Screenshot


![Screenshot of Photographer]
(https://raw.githubusercontent.com/technext/Photographer/master/PHOTOGRAPHER.jpg)

#Demo Link
Check out the demo of Flusk responsive HTML template at (http://themewagon.com/demo/Photographer/)





